// spec.js

// TODO: Add your code here
console.log("Hello from spec.js!");
// NOTE: You can use JQuery here
console.log("JQuery is available in spec.js", $);
